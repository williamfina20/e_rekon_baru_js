
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h2 class="mb-0 fw-bold">Data Rekon</h2>
                <h4>
                    <?php echo e($data_rekon->bandara->user ? $data_rekon->bandara->user->name : ''); ?> <i
                        class="mdi mdi-arrow-right"></i>
                    <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?>(<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)
                </h4>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('maskapai_staf.datarekon')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <?php
        use PhpOffice\PhpSpreadsheet\Shared\Date;
    ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <?php
                            $jumlah_error_maskapai = 0;
                        ?>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <?php $__currentLoopData = $data_a[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($items != 'NO'): ?>
                                            <th><?php echo e($items); ?></th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_items => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!in_array($b_item['AWB'], $tampung_kunci)): ?>
                                        <tr class="text-info">
                                            <?php $__currentLoopData = $b_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_kunci => $b_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($b_kunci != 'NO'): ?>
                                                    <td><?php echo e($b_isi); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>Data AWB Bandara yang tidak ada di Maskapai</td>
                                            <td>
                                                <?php
                                                    $jumlah_error_maskapai++;
                                                    
                                                ?>
                                                <form
                                                    action="<?php echo e(route('maskapai_staf.datarekon.bandingkan_tambah', $data_rekon->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <input type="hidden" name="baris_id" value="<?php echo e($b_items); ?>">
                                                    <button type="submit" class="btn btn-info btn-sm"
                                                        onclick="return confirm('Yakin Ingin Ditambahkan')">Tambah</a>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php $__currentLoopData = $data_a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_items => $a_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($a_validasi_awb_tidak_ada[$a_items] == 'tidak'): ?>
                                        <tr class="text-danger">
                                            <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($a_kunci != 'NO'): ?>
                                                    <td><?php echo e($a_isi); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>Data AWB tidak ditemukan</td>
                                            <td>
                                                <?php
                                                    $jumlah_error_maskapai++;
                                                ?>
                                                <form
                                                    action="<?php echo e(route('maskapai_staf.datarekon.bandingkan_hapus', $data_rekon->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <input type="hidden" name="baris_id" value="<?php echo e($a_items); ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm"
                                                        onclick="return confirm('Yakin Ingin Menghapus')">Hapus</a>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php if($a_validasi_awb_sama[$a_items] > 1): ?>
                                            <tr class="text-warning">
                                                <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($a_kunci != 'NO'): ?>
                                                        <td><?php echo e($a_isi); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td>Terdapat Data AWB yang sama</td>
                                                <td>
                                                    <?php
                                                        $jumlah_error_maskapai++;
                                                    ?>
                                                    <button type="button"
                                                        onclick="UpdateData(<?php echo e($a_items); ?>,<?php echo e(json_encode($a_item)); ?>)"
                                                        class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal">
                                                        Edit
                                                    </button>
                                                    <form
                                                        action="<?php echo e(route('maskapai_staf.datarekon.bandingkan_hapus', $data_rekon->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <input type="hidden" name="baris_id" value="<?php echo e($a_items); ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            onclick="return confirm('Yakin Ingin Menghapus')">Hapus</a>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <?php $__currentLoopData = $data_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_items => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(in_array($a_item['AWB'], $b_item)): ?>
                                                        <?php
                                                            $jumlah_kolom_error = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($a_isi == $b_item[$a_kunci]): ?>
                                                                <?php if($a_kunci != 'NO'): ?>
                                                                    <td><?php echo e($a_isi); ?></td>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($a_kunci != 'NO'): ?>
                                                                    <?php
                                                                        $jumlah_kolom_error++;
                                                                    ?>
                                                                    <td>
                                                                        <div class="d-flex">
                                                                            <?php echo e($a_isi); ?>

                                                                            <i class="mdi mdi-arrow-right text-info"></i>
                                                                            <?php echo e($b_item[$a_kunci]); ?>

                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($jumlah_kolom_error > 0): ?>
                                                            <td>Data Yang berbeda</td>
                                                            <td>
                                                                <?php
                                                                    $jumlah_error_maskapai++;
                                                                ?>
                                                                <button type="button"
                                                                    onclick="UpdateData(<?php echo e($a_items); ?>,<?php echo e(json_encode($a_item)); ?>,<?php echo e(json_encode($b_item)); ?>)"
                                                                    class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                                                    data-bs-target="#exampleModal">
                                                                    Edit
                                                                </button>
                                                            </td>
                                                        <?php else: ?>
                                                            <td></td>
                                                            <td></td>
                                                        <?php endif; ?>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                    <div>
                        Keterangan:
                        <table width="50%">
                            <tr>
                                <td class="fw-bold">Jumlah Data</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e(count($data_a)); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Bandara Error</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e($jumlah_error_bandara); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Maskapai Error</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e($jumlah_error_maskapai); ?></td>
                            </tr>
                            <tr>
                                <td class="text-info">Text Biru</td>
                                <td>:</td>
                                <td>Data AWB Bandara yang tidak ada di Maskapai</td>
                            </tr>
                            <tr>
                                <td class="text-danger">Text Merah</td>
                                <td>:</td>
                                <td>Data AWB tidak ditemukan</td>
                            </tr>
                            <tr>
                                <td class="text-warning">Text Orange</td>
                                <td>:</td>
                                <td>Terdapat Data AWB yang sama </td>
                            </tr>
                            <tr>
                                <td><i class="mdi mdi-arrow-right text-info"></i></td>
                                <td>:</td>
                                <td>Data Yang berbeda</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body table-responsive">
                    <h4 class="text-muted mb-3">Perubahan Rekon</h4>
                    <table class="table" id="example2">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Akun</th>
                                <th>Proses</th>
                                <th>Riwayat Ubah</th>
                                <th>Waktu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $riwayat_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php echo $akun = App\Http\Controllers\PanggilFungsiController::tampil_akun_bandara_atau_maskapai(
                                            $item->akun_tipe,
                                            $item->akun_id,
                                        ); ?>

                                    </td>
                                    <td><?php echo e($item->proses); ?></td>
                                    <td>
                                        <?php
                                            $riwayat_ubah = json_decode($item->riwayat_ubah, true);
                                            foreach ($riwayat_ubah as $kunci_ru => $isi_ru) {
                                                if ($kunci_ru != 'NO') {
                                                    echo $kunci_ru . ': ' . $isi_ru . ',&nbsp;&nbsp;';
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td><?php echo e(date('H:i:s d/m/Y', strtotime($item->created_at))); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <!-- Column -->
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('maskapai_staf.datarekon.bandingkan_edit', $data_rekon->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Data</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="baris_id" class="form-control" id="baris_id">
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $data_a[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($items != 'NO'): ?>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <label><?php echo e($items); ?></label>
                                        <span class="text-muted" id="perbedaan<?php echo e($items); ?>"></span>
                                    </div>
                                    <input type="text" name="data_edit[<?php echo e($items); ?>]"
                                        id="<?php echo e($items); ?>" class="form-control" value="">
                                </div>
                            <?php else: ?>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        
                                        <span class="text-muted" id="perbedaan<?php echo e($items); ?>"></span>
                                    </div>
                                    <input type="hidden" name="data_edit[<?php echo e($items); ?>]"
                                        id="<?php echo e($items); ?>" class="form-control" value="" readonly>
                                </div>
                            <?php endif; ?>
                            <?php
                                $i++;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function UpdateData(baris_id, baris_a, baris_b = false) {
            for (let key in baris_a) {
                document.getElementById(`perbedaan${key}`).innerText = '';
                let inputdata = document.getElementById(key).value = baris_a[key];
                if (baris_b) {
                    if (baris_a[key].toString() !== baris_b[key].toString()) {
                        if (key != 'NO') {
                            document.getElementById(`perbedaan${key}`).innerText = `${baris_a[key]} -> ${baris_b[key]}`;
                        }
                    }
                }
            }
            document.getElementById('baris_id').value = baris_id;
        }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maskapai_staf.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/maskapai_staf/datarekon/bandingkan_php.blade.php ENDPATH**/ ?>