<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Flexy lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Flexy admin lite design, Flexy admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Flexy Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>
        E-Rekon Kode Bandara
        <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->bandara->user->name : ''); ?> -
        <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?> -
        (<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)
    </title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/Flexy-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('flexy/assets/images/favicon.png')); ?>">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('flexy/dist/css/style.min.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    
    <script src="https://cdn.ckeditor.com/4.21.0/full/ckeditor.js"></script>
    <style>
        /* @media print {
            @page {
                margin-top: 10px;
                margin-bottom: 0;
            }

            body {
                padding-top: 72px;
                padding-bottom: 72px;
            }
        } */
    </style>
</head>

<body>
    <div>
        <div class="text-end">
            <img src="<?php echo e(asset('aplog.jpeg')); ?>" width="300">
        </div>
        <h5 class="text-center" style="text-transform: uppercase">
            BERITA ACARA <br />
            REKONSILIASI PRODUKSI ATAS PERJANJIAN KERJASAMA PENANGANAN KARGO & KOS<br />
            <?php echo e($data_rekon->bandara ? $data_rekon->bandara->user->name : ''); ?>

            DAN
            <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?>

            
            <BR />
            PERIODE <?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>

        </h5>
        <center>
            <?php
                $total = 0;
                $kunci = [];
            ?>
            <div class="border-top border-dark py-2">
                <div class="text-start">
                    Informasi surat ini dinyatakan sah dan sesuai dengan sistem E-Rekon milik PT. Angkasa Pura Logistik
                </div>
                
                <div>
                    <div class="text-start">
                        <div class="text-center mt-2">
                            Informasi Rekonsiliasi Produksi
                        </div>
                        <center>
                            <table class="table table-bordered" style="width: 90%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Produksi</th>
                                        <th>Berat (Kg)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data_produksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total += (int) $item;
                                        ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($items); ?></td>
                                            <td><?php echo e($item); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="2">Total Produksi</td>
                                        <td><?php echo e($total); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </center>
                        <p>
                            Nomor Berita Acara Rekonsiliasi :
                            ER.0<?php echo e($no_berita_acara); ?>/Hk.06.03/<?php echo e(date('Y', strtotime($data_rekon->bulan))); ?>/<?php echo e($data_rekon->bandara ? $data_rekon->bandara->kode_jabatan : ''); ?>

                            <br />
                            <?php
                                $waktu_admin = new DateTime($data_rekon->admin_acc);
                                $waktu_maskapai = new DateTime($data_rekon->maskapai_acc);
                            ?>
                            Tanggal Berita Acara :
                            <?php if($waktu_admin >= $waktu_maskapai): ?>
                                <?php echo e(date('H:i:s d/m/Y', strtotime($data_rekon->admin_acc))); ?>

                            <?php else: ?>
                                <?php echo e(date('H:i:s d/m/Y', strtotime($data_rekon->maskapai_acc))); ?>

                            <?php endif; ?>
                            <br />
                            Perihal:
                            Berita Acara Rekonsiliasi Produksi PT. Angkasa Pura Logistik
                        </p>
                        <p>
                            Verifikator Angkasa Pura Logistik :
                            <?php if($data_rekon->bandara): ?>
                                <?php if($data_rekon->bandara->user): ?>
                                    <?php echo e($berita_acara->bandara_nama_pimpinan); ?> -
                                    <?php echo e($berita_acara->bandara_jabatan_pimpinan); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                            <br />
                            Tim Rekonsiliasi Angkasa Pura Logistik :
                            <br />
                            <?php if($data_rekon->bandara->bandara_staf): ?>
                                <?php $__currentLoopData = $data_rekon->bandara->bandara_staf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->user): ?>
                                        <?php echo e($item->user->name); ?> - <?php echo e($item->jabatan_staf); ?>

                                        <br />
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </p>
                        <p>
                            Verifikator Maskapai :
                            <?php if($data_rekon->maskapai): ?>
                                <?php echo e($berita_acara->maskapai_nama_pimpinan); ?> -
                                <?php echo e($berita_acara->maskapai_jabatan_pimpinan); ?>

                            <?php endif; ?>
                            <br />
                            Tim Rekonsiliasi Maskapai :
                            <br />
                            <?php if($data_rekon->maskapai->maskapai_staf): ?>
                                <?php $__currentLoopData = $data_rekon->maskapai->maskapai_staf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->user): ?>
                                        <?php echo e($item->user->name); ?> - <?php echo e($item->jabatan_staf); ?>

                                        <br />
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <br />
                            Tanggal Rekon : <?php echo e(date('H:i:s d/m/Y', strtotime($data_rekon->created_at))); ?>

                        </p>
                        <div class="text-center">
                            <span>Riwayat Perubahan Rekonsiliasi</span>
                        </div>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Akun</th>
                                    <th>Proses</th>
                                    <th>Riwayat Ubah</th>
                                    <th>Waktu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $riwayat_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php echo $akun = App\Http\Controllers\PanggilFungsiController::tampil_akun_bandara_atau_maskapai(
                                                $item->akun_tipe,
                                                $item->akun_id,
                                            ); ?>

                                        </td>
                                        <td><?php echo e($item->proses); ?></td>
                                        <td>
                                            <?php
                                                $riwayat_ubah = json_decode($item->riwayat_ubah, true);
                                                foreach ($riwayat_ubah as $kunci_ru => $isi_ru) {
                                                    if ($kunci_ru != 'NO') {
                                                        echo $kunci_ru . ': ' . $isi_ru . ',&nbsp;&nbsp;';
                                                    }
                                                }
                                            ?>
                                        </td>
                                        <td><?php echo e(date('H:i:s d/m/Y', strtotime($item->created_at))); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </center>
    </div>


    <script>
        // var css = '@page { size: portrait; }',
        //     head = document.head || document.getElementsByTagName('head')[0],
        //     style = document.createElement('style');

        // style.type = 'text/css';
        // style.media = 'print';

        // if (style.styleSheet) {
        //     style.styleSheet.cssText = css;
        // } else {
        //     style.appendChild(document.createTextNode(css));
        // }

        // head.appendChild(style);

        window.print();
    </script>
</body>

</html>
<?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/datarekon/kode_bandara.blade.php ENDPATH**/ ?>