
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h2 class="mb-0 fw-bold">Data Rekon</h2>
                <h4>
                    <?php echo e($data_rekon->bandara->user ? $data_rekon->bandara->user->name : ''); ?> <i
                        class="mdi mdi-arrow-right"></i>
                    <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?>(<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)
                </h4>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('maskapai_pusat.datarekon.show', $data_rekon->maskapai->id)); ?>"
                    class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <?php
        use PhpOffice\PhpSpreadsheet\Shared\Date;
    ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <?php
                            $jumlah_error_maskapai = 0;
                        ?>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <?php $__currentLoopData = $data_a[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($items != 'NO'): ?>
                                            <th><?php echo e($items); ?></th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_items => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!in_array($b_item['AWB'], $tampung_kunci)): ?>
                                        <tr class="text-info">
                                            <?php $__currentLoopData = $b_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_kunci => $b_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($b_kunci != 'NO'): ?>
                                                    <td><?php echo e($b_isi); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>Data AWB Bandara yang tidak ada di Maskapai</td>
                                            <?php
                                                $jumlah_error_maskapai++;
                                                
                                            ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php $__currentLoopData = $data_a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_items => $a_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($a_validasi_awb_tidak_ada[$a_items] == 'tidak'): ?>
                                        <tr class="text-danger">
                                            <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($a_kunci != 'NO'): ?>
                                                    <td><?php echo e($a_isi); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>Data AWB tidak ditemukan</td>
                                            <?php
                                                $jumlah_error_maskapai++;
                                            ?>
                                        </tr>
                                    <?php else: ?>
                                        <?php if($a_validasi_awb_sama[$a_items] > 1): ?>
                                            <tr class="text-warning">
                                                <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($a_kunci != 'NO'): ?>
                                                        <td><?php echo e($a_isi); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td>Terdapat Data AWB yang sama</td>
                                                <?php
                                                    $jumlah_error_maskapai++;
                                                ?>
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <?php $__currentLoopData = $data_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_items => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(in_array($a_item['AWB'], $b_item)): ?>
                                                        <?php
                                                            $jumlah_kolom_error = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $a_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_kunci => $a_isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($a_isi == $b_item[$a_kunci]): ?>
                                                                <?php if($a_kunci != 'NO'): ?>
                                                                    <td><?php echo e($a_isi); ?></td>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($a_kunci != 'NO'): ?>
                                                                    <?php
                                                                        $jumlah_kolom_error++;
                                                                    ?>
                                                                    <td>
                                                                        <div class="d-flex">
                                                                            <?php echo e($a_isi); ?>

                                                                            <i class="mdi mdi-arrow-right text-info"></i>
                                                                            <?php echo e($b_item[$a_kunci]); ?>

                                                                        </div>
                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($jumlah_kolom_error > 0): ?>
                                                            <td>Data Yang berbeda</td>
                                                            <?php
                                                                $jumlah_error_maskapai++;
                                                            ?>
                                                        <?php else: ?>
                                                            <td></td>
                                                        <?php endif; ?>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                    <div>
                        <div class="my-2">
                            <?php if($data_rekon->maskapai_status == 1): ?>
                                <form action="<?php echo e(route('maskapai_pusat.datarekon.persetujuan', $data_rekon->id)); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-success text-white my-2">Persetujuan<i
                                            class="mdi mdi-check"></i></button>
                                </form>
                            <?php endif; ?>
                        </div>
                        Keterangan:
                        <table width="50%">
                            <tr>
                                <td class="fw-bold">Jumlah Data</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e(count($data_a)); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Bandara Error</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e($jumlah_error_bandara); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Maskapai Error</td>
                                <td>:</td>
                                <td class="fw-bold"><?php echo e($jumlah_error_maskapai); ?></td>
                            </tr>
                            <tr>
                                <td class="text-info">Text Biru</td>
                                <td>:</td>
                                <td>Data AWB Bandara yang tidak ada di Maskapai</td>
                            </tr>
                            <tr>
                                <td class="text-danger">Text Merah</td>
                                <td>:</td>
                                <td>Data AWB tidak ditemukan</td>
                            </tr>
                            <tr>
                                <td class="text-warning">Text Orange</td>
                                <td>:</td>
                                <td>Terdapat Data AWB yang sama </td>
                            </tr>
                            <tr>
                                <td><i class="mdi mdi-arrow-right text-info"></i></td>
                                <td>:</td>
                                <td>Data Yang berbeda</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body table-responsive">
                    <h4 class="text-muted mb-3">Perubahan Rekon</h4>
                    <table class="table" id="example2">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Akun</th>
                                <th>Proses</th>
                                <th>Riwayat Ubah</th>
                                <th>Waktu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $riwayat_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php echo $akun = App\Http\Controllers\PanggilFungsiController::tampil_akun_bandara_atau_maskapai(
                                            $item->akun_tipe,
                                            $item->akun_id,
                                        ); ?>

                                    </td>
                                    <td><?php echo e($item->proses); ?></td>
                                    <td>
                                        <?php
                                            $riwayat_ubah = json_decode($item->riwayat_ubah, true);
                                            foreach ($riwayat_ubah as $kunci_ru => $isi_ru) {
                                                if ($kunci_ru != 'NO') {
                                                    echo $kunci_ru . ': ' . $isi_ru . ',&nbsp;&nbsp;';
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td><?php echo e(date('H:i:s d/m/Y', strtotime($item->created_at))); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <!-- Column -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maskapai_pusat.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/maskapai_pusat/datarekon/bandingkan_php.blade.php ENDPATH**/ ?>