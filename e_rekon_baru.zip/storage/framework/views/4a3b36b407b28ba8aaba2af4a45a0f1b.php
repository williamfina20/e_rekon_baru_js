<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Flexy lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Flexy admin lite design, Flexy admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Flexy Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>
        Berita Acara 2 E-Rekon
        <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->bandara->user->name : ''); ?> -
        <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?> -
        (<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)
    </title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/Flexy-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('flexy/assets/images/favicon.png')); ?>">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('flexy/dist/css/style.min.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    
    <script src="https://cdn.ckeditor.com/4.21.0/full/ckeditor.js"></script>
    <style>
        /* @media print {
            @page {
                margin-top: 10px;
                margin-bottom: 0;
            }

            body {
                padding-top: 72px;
                padding-bottom: 72px;
            }
        } */
    </style>
</head>

<body>
    <?php
        $admin = DB::table('users')
            ->where('level', 'admin')
            ->first();
    ?>
    <div>
        <div class="text-end">
            <img src="<?php echo e(asset('aplog.jpeg')); ?>" width="300">
        </div>
        <h5 class="text-center" style="text-transform: uppercase">
            BERITA ACARA <br />
            REKONSILIASI PRODUKSI ATAS PERJANJIAN KERJASAMA PENANGANAN KARGO & KOS<br />
            <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?> DAN
            <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->bandara->user->name : ''); ?> DI BANDAR UDARA INTERNATIONAL
            ELTARI KUPANG<BR />
            PERIODE <?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>

        </h5>
        <center>
            <?php
                $total = 0;
            ?>
            <table class="table table-bordered table-bordered" style="width: 90%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Produksi</th>
                        <th>Berat (Kg)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_produksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total += (int) $item;
                        ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($items); ?></td>
                            <td><?php echo e($item); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="2">Total Produksi</td>
                        <td><?php echo e($total); ?></td>
                    </tr>
                </tbody>
            </table>
            <br />
            <table style="width: 90%">
                <tr>
                    <td style="text-align: center;width: 45%;vertical-align: top;" class="text-capitalize">
                        <?php if($data_rekon->bandara): ?>
                            <?php if($data_rekon->bandara->user): ?>
                                <?php echo e($data_rekon->bandara->user->name); ?>

                                <br />
                                <?php echo e($data_rekon->bandara->jabatan_pimpinan); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td style="width: 10%"></td>
                    <td style="text-align: center;width: 45%;vertical-align: top;" class="text-capitalize">
                        <?php if($data_rekon->maskapai): ?>
                            <?php if($data_rekon->maskapai->user): ?>
                                <?php echo e($data_rekon->maskapai->user->name); ?>

                                <br />
                                <?php echo e($data_rekon->maskapai->jabatan_pimpinan); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;width: 45%" class="text-center">
                        <?php if($data_rekon->bandara): ?>
                            <?php if($data_rekon->bandara->user): ?>
                                <?php
                                    echo DNS2D::getBarcodeSVG($data_rekon->bandara->nama_pimpinan, 'QRCode', 3, 3);
                                ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td style="width: 10%">
                    </td>
                    <td style="text-align: center;width: 45%">
                        <?php if($data_rekon->maskapai): ?>
                            <?php if($data_rekon->maskapai->user): ?>
                                <?php
                                    echo DNS2D::getBarcodeSVG($data_rekon->maskapai->nama_pimpinan, 'QRCode', 3, 3);
                                ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </td>
                </tr>
                <tr>
                    <td style="text-align: center;width: 45%">
                        <?php if($data_rekon->bandara): ?>
                            <?php if($data_rekon->bandara->user): ?>
                                <?php echo e($data_rekon->bandara->nama_pimpinan); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td style="width: 10%"></td>
                    <td style="text-align: center;width: 45%">
                        <?php if($data_rekon->maskapai): ?>
                            <?php if($data_rekon->maskapai->user): ?>
                                <?php echo e($data_rekon->maskapai->nama_pimpinan); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>

            </table>
        </center>
    </div>



    <script>
        window.print();
    </script>
</body>

</html>
<?php /**PATH D:\@Code\Laravel\Project\e_rekon\resources\views/maskapai/datarekon/lihat_berita_2.blade.php ENDPATH**/ ?>