
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="d-flex justify-content-between">
            <div>
                <h1 class="mb-0 fw-bold">Laporan Bandara Detail</h1>
                <h3>
                    <?php echo e($bandara->user ? $bandara->user->name : ''); ?>

                </h3>
            </div>
            <div>
                <a href="<?php echo e(route('admin.laporan_bandara')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <?php
        $periode = [];
    ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <button type="button" class="btn btn-primary btn-sm mb-1" data-bs-toggle="modal"
                            data-bs-target="#exampleModal">
                            Cetak Semua
                        </button>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Periode</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $maskapai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <form action="<?php echo e(route('admin.laporan_bandara_cetak', $item->id)); ?>" method="get">
                                            <?php echo csrf_field(); ?>
                                            <?php
                                                $rekon = $item->rekon;
                                            ?>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <?php echo e($item->user ? $item->user->name : ''); ?>

                                            </td>
                                            <td>
                                                <select name="rekon" class="form-control" required>
                                                    <?php
                                                        $cek_jumlah = 0;
                                                    ?>
                                                    <?php if($item->rekon->count() > 0): ?>
                                                        <?php $__currentLoopData = $rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($r->admin_acc and $r->maskapai_acc): ?>
                                                                <option value="<?php echo e($r->id); ?>">
                                                                    <?php echo e(date('F Y', strtotime($r->bulan))); ?>

                                                                </option>
                                                                <?php
                                                                    $cek_jumlah++;
                                                                    if (!in_array($r->bulan, $periode)) {
                                                                        array_push($periode, $r->bulan);
                                                                    }
                                                                ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($cek_jumlah > 0): ?>
                                                            <option value="semua" selected>semua</option>
                                                        <?php else: ?>
                                                            <option value="" selected></option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                            <td>
                                                <?php if($cek_jumlah > 0): ?>
                                                    <button type="submit" class="btn btn-primary btn-sm">Cetak</button>
                                                <?php endif; ?>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                        Cetak Semua Laporan -
                        <?php echo e($bandara->user ? $bandara->user->name : ''); ?>

                    </h1>
                    <br />
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php
                    sort($periode);
                ?>
                <form action="<?php echo e(route('admin.laporan_bandara_cetak_semua', $bandara->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label>Periode</label>
                            <select name="bulan" class="form-control" required>
                                <?php if($periode): ?>
                                    <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item); ?>"> <?php echo e(date('F Y', strtotime($item))); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="semua" selected>semua</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Cetak</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/laporan/laporan_bandara_detail.blade.php ENDPATH**/ ?>