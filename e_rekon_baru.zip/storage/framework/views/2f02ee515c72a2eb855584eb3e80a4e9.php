
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h2 class="mb-0 fw-bold">Data Rekon</h2>
                <h4>
                    <?php echo e($data_rekon->bandara->user ? $data_rekon->bandara->user->name : ''); ?> <i
                        class="mdi mdi-arrow-right"></i>
                    <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?>(<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)
                </h4>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('bandara.datarekon.show', $data_rekon->maskapai_id)); ?>"
                    class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <?php
        use PhpOffice\PhpSpreadsheet\Shared\Date;
    ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <div class="d-flex">
                            <div class="d-flex me-5">
                                <i class="mdi mdi-play-circle text-primary"></i>
                                Rekon Admin
                            </div>
                            <div class="d-flex">
                                <i class="mdi mdi-play-circle text-danger"></i>
                                Rekon Maskapai
                            </div>
                        </div>
                        <div id="bandara_rekon_bandingkan"></div>
                        <?php
                            $data_rekon_2 = json_encode($data_rekon);
                            $data_maskapai_2 = json_encode($data_maskapai);
                        ?>
                        <?php if($data_rekon->rekon_admin_text == $data_rekon->rekon_maskapai_text): ?>
                            <div class="table-responsive">
                                <?php
                                    $data_rekon_admin = json_decode($data_rekon->rekon_admin_text, true);
                                ?>
                                <table class="table table-striped" id="example">
                                    <thead>
                                        <tr>
                                            <?php $__currentLoopData = array_keys($data_rekon_admin[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($item); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data_rekon_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($isi); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php if(!$data_rekon->status): ?>
                                <form action="<?php echo e(route('bandara.datarekon.kirim', $data_rekon->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success text-white btn-sm my-2">Kirim Rekon Ke
                                        Pusat</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Riwayat Ubah</th>
                                    <th>Waktu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $riwayat_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php
                                                $riwayat_ubah = json_decode($item->riwayat_ubah);
                                            ?>
                                            <?php if($item->bandara): ?>
                                                <?php echo e($item->bandara->user->name); ?>

                                            <?php endif; ?>
                                            <?php if($item->maskapai): ?>
                                                <?php echo e($item->maskapai->user->name); ?>

                                            <?php endif; ?>
                                            <?php $__currentLoopData = $riwayat_ubah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <br /><?php echo e('Mengubah data ke-' . ((int) $item2->id + 1) . ' kolom ' . $item2->id_kolom . ' menjadi ' . $item2->isi); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e(date('H:i:s d/m/Y', strtotime($item->created_at))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
        <script>
            window.data_rekon = <?= $data_rekon_2 ?>;
            window.data_maskapai = <?= $data_maskapai_2 ?>;
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bandara.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/bandara/datarekon/bandingkan.blade.php ENDPATH**/ ?>