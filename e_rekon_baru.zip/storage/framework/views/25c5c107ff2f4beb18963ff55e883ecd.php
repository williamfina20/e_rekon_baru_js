
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h1 class="mb-0 fw-bold">Data Rekon - <?php echo e($data_maskapai->name); ?></h1>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('admin.datarekon')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <a href="<?php echo e(route('admin.datarekon.create', $data_maskapai->id)); ?>"
                            class="btn btn-primary btn-sm mb-2">Tambah</a>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Rekon Admin</th>
                                    <th>Rekon Maskapai</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('F Y', strtotime($item->bulan))); ?></td>
                                        <td>
                                            <?php if($item->rekon_admin): ?>
                                                <a href="<?php echo e(asset('storage/' . $item->rekon_admin)); ?>" target="_blank"
                                                    class="btn btn-link"><i class="mdi mdi-eye  text-primary"></i>
                                                    Lihat
                                                </a>
                                            <?php else: ?>
                                                <i class="mdi mdi-close-circle text-danger"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->rekon_maskapai): ?>
                                                <a href="<?php echo e(asset('storage/' . $item->rekon_maskapai)); ?>" target="_blank"
                                                    class="btn btn-link"><i class="mdi mdi-eye  text-primary"></i>
                                                    Lihat
                                                </a>
                                            <?php else: ?>
                                                <i class="mdi mdi-close-circle text-danger"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.datarekon.destroy', $item->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <a href="<?php echo e(route('admin.datarekon.bandingkan', $item->id)); ?>"
                                                    class="btn btn-info btn-sm text-white <?php if(!$item->rekon_admin or !$item->rekon_maskapai): ?> disabled <?php endif; ?>">Bandingkan</a>
                                                <?php if($item->status == 1): ?>
                                                    <a href="<?php echo e(route('admin.datarekon.lihat_berita', $item->id)); ?>"
                                                        target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                        Acara 1</a>
                                                    <a href="<?php echo e(route('admin.datarekon.lihat_berita_2', $item->id)); ?>"
                                                        target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                        Acara 2</a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('admin.datarekon.edit', $item->id)); ?>"
                                                        class="btn btn-warning btn-sm">Edit</a>
                                                    <button type="submit"
                                                        onclick="return confirm('Yakin ingin menghapus?')"
                                                        class="btn btn-danger text-white btn-sm">Hapus</button>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bandara.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon\resources\views/bandara/datarekon/view.blade.php ENDPATH**/ ?>