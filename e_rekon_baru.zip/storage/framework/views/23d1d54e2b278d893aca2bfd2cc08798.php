
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <h1 class="mb-0 fw-bold">Edit Invoice</h1>
        <h3>
            <?php echo e($data_maskapai->bandara ? $data_maskapai->bandara->user->name : ''); ?> -
            <?php echo e($data_maskapai->user ? $data_maskapai->user->name : ''); ?> -
            <?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>

        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.datarekon.update_invoice', $data_rekon->id)); ?>" method="post">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label>No Invoice</label>
                                <input type="text" name="no_invoice" class="form-control"
                                    value="<?php echo e($data_rekon->no_invoice); ?>">
                                <?php $__errorArgs = ['no_invoice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label>No Faktur Pajak</label>
                                <input type="text" name="no_faktur_pajak" class="form-control"
                                    value="<?php echo e($data_rekon->no_faktur_pajak); ?>">
                                <?php $__errorArgs = ['no_faktur_pajak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <a href="<?php echo e(route('admin.datarekon.show', $data_maskapai->id)); ?>"
                                    class="btn btn-secondary btn-sm">Kembali</a>
                                <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/datarekon/edit_invoice.blade.php ENDPATH**/ ?>