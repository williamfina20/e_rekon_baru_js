
<?php $__env->startSection('content'); ?>
    <div class="mx-4 d-flex justify-content-between">
        <div>
            <h1 class="mb-0 fw-bold">Data Rekon </h1>
            <h3><?php echo e($maskapai_pusat->name); ?></h3>
        </div>
        <div>
            <a href="<?php echo e(route('bisnis.datarekon')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <table class="table table-hover" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Periode</th>
                                    <th>Jumlah Berita Acara</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    
                                ?>
                                <?php $__currentLoopData = $periode_jumlah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('F Y', strtotime($items))); ?></td>
                                        <td><?php echo e($item); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('bisnis.datarekon.show', $maskapai_pusat->id)); ?>"
                                                method="get">
                                                <input type="hidden" name="bulan" value="<?php echo e($items); ?>" />
                                                <button class="btn btn-info btn-sm text-white" type="submit">Lihat</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bisnis.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/bisnis/datarekon/maskapai.blade.php ENDPATH**/ ?>