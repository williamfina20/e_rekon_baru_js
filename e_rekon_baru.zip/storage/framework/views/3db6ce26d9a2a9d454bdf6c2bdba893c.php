
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <h1 class="mb-0 fw-bold">Data Staf <?php if($bandara->user): ?>
                <?php echo e($bandara->user->name); ?>

            <?php endif; ?>
        </h1>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('admin.bandara_staf.create', $bandara->id)); ?>"
                                class="btn btn-primary btn-sm mb-2">Tambah</a>
                            <a href="<?php echo e(route('admin.databandara')); ?>" class="btn btn-secondary btn-sm mb-2">kembali</a>
                        </div>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                    <th>Username</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bandara_staf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php if($item->user): ?>
                                                <?php echo e($item->user->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->jabatan_staf); ?></td>
                                        <td>
                                            <?php if($item->user): ?>
                                                <?php echo e($item->user->email); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.bandara_staf.destroy', $item->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <a href="<?php echo e(route('admin.bandara_staf.edit', $item->id)); ?>"
                                                    class="btn btn-warning btn-sm">Edit</a>
                                                <button type="submit" onclick="return confirm('Yakin ingin menghapus?')"
                                                    class="btn btn-danger text-white btn-sm">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/bandara_staf/index.blade.php ENDPATH**/ ?>