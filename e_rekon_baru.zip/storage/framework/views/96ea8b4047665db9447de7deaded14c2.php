
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h1 class="mb-0 fw-bold">Data Rekon - <?php echo e($data_maskapai->user ? $data_maskapai->user->name : ''); ?></h1>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('bandara_staf.datarekon.create', $data_maskapai->id)); ?>"
                                class="btn btn-primary btn-sm mb-2">Tambah</a>
                            <a href="<?php echo e(route('bandara_staf.datarekon')); ?>"
                                class="btn btn-secondary btn-sm mb-2">Kembali</a>
                        </div>
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>Rekon Admin</th>
                                    <th>Rekon Maskapai</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('F Y', strtotime($item->bulan))); ?></td>
                                        <td>
                                            <?php if(!$item->rekon_admin_text): ?>
                                                Rekon Belum diupload
                                            <?php endif; ?>
                                            <?php if($item->admin_acc): ?>
                                                Selesai <i class="mdi mdi-check"></i>
                                            <?php elseif($item->admin_status == 2): ?>
                                                Telah Disetujui Pusat
                                            <?php elseif($item->admin_status == 1): ?>
                                                Menunggu Konfirmasi Pusat
                                            <?php elseif($item->riwayat_rekon->count() != 0): ?>
                                                Proses Rekon
                                            <?php elseif($item->rekon_admin_text and $item->rekon_maskapai_text): ?>
                                                Proses Rekon sudah dapat dilakukan
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!$item->rekon_maskapai_text): ?>
                                                Rekon Belum diupload
                                            <?php endif; ?>
                                            <?php if($item->maskapai_acc): ?>
                                                Selesai <i class="mdi mdi-check"></i>
                                            <?php elseif($item->maskapai_status == 2): ?>
                                                Telah Disetujui Pusat
                                            <?php elseif($item->maskapai_status == 1): ?>
                                                Menunggu Konfirmasi Pusat
                                            <?php elseif($item->riwayat_rekon->count() != 0): ?>
                                                Proses Rekon
                                            <?php elseif($item->rekon_admin_text and $item->rekon_maskapai_text): ?>
                                                Proses Rekon sudah dapat dilakukan
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('bandara_staf.datarekon.destroy', $item->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <a href="<?php echo e(route('bandara_staf.datarekon.bandingkan', $item->id)); ?>"
                                                    class="btn btn-info btn-sm text-white <?php if(!$item->rekon_admin_text or !$item->rekon_maskapai_text): ?> disabled <?php endif; ?>">
                                                    <?php if(!$item->admin_status or !$item->maskapai_status): ?>
                                                        Bandingkan
                                                    <?php else: ?>
                                                        Lihat
                                                    <?php endif; ?>
                                                </a>
                                                <?php if($item->admin_status == 2 and $item->maskapai_status == 2): ?>
                                                    <?php if($item->admin_acc and $item->maskapai_acc): ?>
                                                        <a href="<?php echo e(route('admin.datarekon.lihat_berita', $item->id)); ?>"
                                                            target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                            Acara 1</a>
                                                        <a href="<?php echo e(route('admin.datarekon.lihat_berita_2', $item->id)); ?>"
                                                            target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                            Acara 2</a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($item->riwayat_rekon->count() == 0): ?>
                                                        <?php if(!$item->admin_status and !$item->maskapai_status): ?>
                                                            <a href="<?php echo e(route('bandara_staf.datarekon.edit', $item->id)); ?>"
                                                                class="btn btn-warning btn-sm">Edit</a>
                                                            <button type="submit"
                                                                onclick="return confirm('Yakin ingin menghapus?')"
                                                                class="btn btn-danger text-white btn-sm">Hapus</button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bandara_staf.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/bandara_staf/datarekon/show.blade.php ENDPATH**/ ?>