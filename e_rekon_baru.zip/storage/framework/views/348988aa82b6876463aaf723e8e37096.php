
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <h1 class="mb-0 fw-bold">Edit Rekon</h1>
        <h3>
            <?php echo e($data_maskapai->bandara ? $data_maskapai->bandara->user->name : ''); ?> -
            <?php echo e($data_maskapai->user ? $data_maskapai->user->name : ''); ?>

        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <?php if($data_rekon->status != 1): ?>
                <div class="col-md-12">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.datarekon.update', $data_rekon->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="mb-3">
                                    <label>Bulan</label>
                                    <input type="month" name="bulan" class="form-control"
                                        value="<?php echo e($data_rekon->bulan); ?>" readonly>
                                    <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label>Rekon Admin</label>
                                    <a href="<?php echo e(asset('storage/' . $data_rekon->rekon_admin)); ?>" target="_blank"
                                        class="btn btn-link"><i class="mdi mdi-eye  text-primary"></i>
                                        Lihat
                                    </a>
                                    <input type="file" name="rekon_admin" class="form-control"
                                        value="<?php echo e(old('rekon_admin')); ?>">
                                    <span class="text-muted">* Kosongkan jika tidak ingin diganti</span>
                                    <?php $__errorArgs = ['rekon_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label>Rekon Maskapai</label>
                                    <a href="<?php echo e(asset('storage/' . $data_rekon->rekon_maskapai)); ?>" target="_blank"
                                        class="btn btn-link"><i class="mdi mdi-eye  text-primary"></i>
                                        Lihat
                                    </a>
                                    <input type="file" name="rekon_maskapai" class="form-control"
                                        value="<?php echo e(old('rekon_maskapai')); ?>">
                                    <span class="text-muted">* Kosongkan jika tidak ingin diganti</span>
                                    <?php $__errorArgs = ['rekon_maskapai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <a href="<?php echo e(route('admin.datarekon.show', $data_maskapai->id)); ?>"
                                        class="btn btn-secondary btn-sm">Kembali</a>
                                    <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/datarekon/edit.blade.php ENDPATH**/ ?>