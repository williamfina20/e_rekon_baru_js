
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h1 class="mb-0 fw-bold">Data Rekon
                </h1>
                <h3><?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->bandara->user->name : ''); ?> -
                    <?php echo e($data_rekon->maskapai ? $data_rekon->maskapai->user->name : ''); ?>

                </h3>
                <h5>(<?php echo e(date('F Y', strtotime($data_rekon->bulan))); ?>)</h5>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('admin.datarekon.show', $data_rekon->maskapai->id)); ?>"
                    class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <?php
        use PhpOffice\PhpSpreadsheet\Shared\Date;
    ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body table-responsive">
                        <table class="table table-bordered border" id="example">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>A</th>
                                    <th>B</th>
                                    <th>C</th>
                                    <th>D</th>
                                    <th>E</th>
                                    <th>F</th>
                                    <th>G</th>
                                    <th>H</th>
                                    <th>I</th>
                                    <th>J</th>
                                    <th>K</th>
                                    <th>L</th>
                                </tr>
                            </thead>
                            <?php
                                $perbedaan = [];
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $data_a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1 => $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data_hasil != []): ?>
                                            <?php if($data_hasil[$items][$item1]): ?>
                                                <tr>
                                                    <td>
                                                        <?php if(in_array('tidak', $data_hasil[$items][$item1])): ?>
                                                            <?php
                                                                array_push($perbedaan, $loop->iteration);
                                                            ?>
                                                            <div class="text-danger">salah</div>
                                                        <?php else: ?>
                                                            <i class="mdi mdi-check"></i>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['A'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['A']); ?>

                                                        <?php if($data_hasil[$items][$item1]['A'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['A']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['B'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['B']); ?>

                                                        <?php if($data_hasil[$items][$item1]['B'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['B']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['C'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['C']); ?>

                                                        <?php if($data_hasil[$items][$item1]['C'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['C']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['D'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['D']); ?>

                                                        <?php if($data_hasil[$items][$item1]['D'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['D']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['E'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['E']); ?>

                                                        <?php if($data_hasil[$items][$item1]['E'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['E']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['F'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['F']); ?>

                                                        <?php if($data_hasil[$items][$item1]['F'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['F']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['G'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['G']); ?>

                                                        <?php if($data_hasil[$items][$item1]['G'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['G']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['H'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['H']); ?>

                                                        <?php if($data_hasil[$items][$item1]['H'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['H']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['I'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['I']); ?>

                                                        <?php if($data_hasil[$items][$item1]['I'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['I']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['J'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['J']); ?>

                                                        <?php if($data_hasil[$items][$item1]['J'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['J']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['K'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['K']); ?>

                                                        <?php if($data_hasil[$items][$item1]['K'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['K']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="<?php if($data_hasil[$items][$item1]['L'] == 'tidak'): ?> text-danger <?php endif; ?>">
                                                        <?php echo e($item2['L']); ?>

                                                        <?php if($data_hasil[$items][$item1]['L'] == 'tidak'): ?>
                                                            <i class="mdi mdi-arrow-right"></i>
                                                            <?php echo e($data_b[$items][$item1]['L']); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td>
                                                        <i class="mdi mdi-alert-circle text-danger"></i>
                                                    </td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'A' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['A']); ?>

                                                    </td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'B' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['B']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'C' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['C']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'D' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['D']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'E' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['E']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'F' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['F']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'G' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['G']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'H' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['H']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'I' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['I']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'J' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['J']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'K' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['K']); ?></td>
                                                    <td
                                                        class=" text-danger <?php echo e($kunci == 'L' ? 'text-decoration-underline fw-bold' : ''); ?>">
                                                        <?php echo e($item2['L']); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <tr>

                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($perbedaan == []): ?>
                            <?php if($data_rekon->status != 1): ?>
                                <form action="<?php echo e(route('admin.datarekon.berita_acara', $data_rekon->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-success text-white"><i
                                            class="mdi mdi-check-circle me-1"></i>Buat
                                        Berita Acara</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon\resources\views/admin/datarekon/bandingkan.blade.php ENDPATH**/ ?>