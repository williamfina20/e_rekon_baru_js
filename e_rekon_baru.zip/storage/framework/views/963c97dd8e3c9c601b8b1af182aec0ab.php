
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="row">
            <div class="col-8">
                <h1 class="mb-0 fw-bold">Data Rekon </h1>
                <h3><?php echo e($data_maskapai->bandara ? $data_maskapai->bandara->user->name : ''); ?> -
                    <?php echo e($data_maskapai->user ? $data_maskapai->user->name : ''); ?></h3>
            </div>
            <div class="col-4 text-end">
                <a href="<?php echo e(route('bisnis.datarekon.maskapai', $data_maskapai->bandara_id)); ?>"
                    class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body table-responsive">
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Bulan</th>
                                    <th>No Invoice</th>
                                    <th>User Invoice</th>
                                    <th>Tanggal Invoice</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_rekon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('F Y', strtotime($item->bulan))); ?></td>
                                        <td><?php echo e($item->no_invoice); ?></td>
                                        <td>
                                            <?php if($item->users_invoice): ?>
                                                <?php echo e($item->users_invoice->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->tanggal_invoice): ?>
                                                <?php echo e(date('H:i:s d/M/Y', strtotime($item->tanggal_invoice))); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->status == 1): ?>
                                                <?php if($item->no_invoice): ?>
                                                    <a href="<?php echo e(route('bisnis.datarekon.lihat_berita', $item->id)); ?>"
                                                        target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                        Acara 1</a>
                                                    <a href="<?php echo e(route('bisnis.datarekon.lihat_berita_2', $item->id)); ?>"
                                                        target="_blank" class="btn btn-success text-white btn-sm">Berita
                                                        Acara 2</a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('bisnis.datarekon.tambah_invoice', $item->id)); ?>"
                                                        class="btn btn-warning text-white btn-sm">Invoice</a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bisnis.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon\resources\views/bisnis/datarekon/show.blade.php ENDPATH**/ ?>