
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <h1 class="mb-0 fw-bold">Edit Rekon - <?php echo e($data_maskapai->user ? $data_maskapai->user->name : ''); ?></h1>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <?php if($data_rekon->status != 1): ?>
                <div class="col-md-12">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div id="bandara_staf_rekon_edit"></div>
                            <?php
                                $data_rekon_2 = json_encode($data_rekon);
                                $data_maskapai_2 = json_encode($data_maskapai);
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Column -->
        </div>
        <script>
            window.data_rekon = <?= $data_rekon_2 ?>;
            window.data_maskapai = <?= $data_maskapai_2 ?>;
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bandara_staf.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/bandara_staf/datarekon/edit.blade.php ENDPATH**/ ?>