
<?php $__env->startSection('content'); ?>
    <div class="mx-4">
        <div class="d-flex justify-content-between">
            <h1 class="mb-0 fw-bold">Laporan Maskapai</h1>
            <div>
                <a href="<?php echo e(route('admin.laporan')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Column -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.laporan_maskapai.cetak')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Bandara</label>
                                    <select name="bandara" class="form-control">
                                        <option value="semua">semua</option>
                                        <?php $__currentLoopData = $bandara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Periode</label>
                                    <select name="periode" class="form-control">
                                        <option value="semua">semua</option>
                                        <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->bulan); ?>"><?php echo e(date('F Y', strtotime($item->bulan))); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary btn-sm">Cetak</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Code\Laravel\Project\e_rekon_baru\resources\views/admin/laporan/laporan_maskapai/index.blade.php ENDPATH**/ ?>